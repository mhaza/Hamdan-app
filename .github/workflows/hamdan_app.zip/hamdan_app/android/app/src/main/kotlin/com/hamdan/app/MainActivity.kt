package com.hamdan.app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
