# خطوات بناء تطبيق همدان واستخراج APK

## الطريقة 1: على جهازك مباشرة

### المتطلبات
1. [Flutter SDK](https://docs.flutter.dev/get-started/install) (قناة مستقرة)
2. Android Studio (يوفر Android SDK + أدوات البناء)

### الخطوات
```bash
# 1. فك الضغط وفتح مجلد المشروع
cd hamdan_app

# 2. تحقق من البيئة
flutter doctor          # يجب أن تكون كل الأدوات ✓

# 3. تثبيت الاعتماديات
flutter pub get

# 4. فحص الكود (اختياري لكن مُستحسن)
flutter analyze

# 5. تشغيل تجريبي على جهاز/محاكي
flutter run

# 6. بناء APK تجريبي (سريع)
flutter build apk --debug
# المخرج: build/app/outputs/flutter-apk/app-debug.apk

# 7. بناء APK نهائي للإصدار
flutter build apk --release
# المخرج: build/app/outputs/flutter-apk/app-release.apk
```

> ملاحظة: APK الـ release غير موقّع بمفتاحك الخاص. للتثبيت المباشر يعمل،
> وللرفع على Google Play أنشئ keystore وفعّل `signingConfigs.release` في
> `android/app/build.gradle` (موضّح مكانها في الملف).

## الطريقة 2: عبر GitHub Actions (بدون تثبيت أي شيء)

1. أنشئ مستودعاً على GitHub وارفع محتوى هذا المجلد كاملاً
   (ملف `.github/workflows/build-apk.yml` موجود مسبقاً).
2. اذهب إلى تبويب **Actions** → اختر سير العمل **Build Hamdan APK**.
3. اضغط **Run workflow** → بعد ~10 دقائق ستجد ملف `app-release.apk`
   قابلاً للتحميل في قسم **Artifacts** صفحة التنفيذ.

## الطريقة 3: عبر خدمات البناء السحابية
ارفع المشروع إلى [Codemagic](https://codemagic.io) أو
[Flutter CI](https://flutter.dev/docs/deployment/cd) وابنِ APK مباشرة.

---

### بناء موقّع (للنشر على Google Play)
```bash
keytool -genkey -v -keystore upload-keystore.jks -keyalg RSA -keysize 2048 -validity 10000 -alias hamdan
```
ثم أضف بياناتك في `android/app/build.gradle` داخل كتلة `signingConfigs.release`
(الحقول موجودة معلّقة وجاهزة)، وأنشئ ملف `android/key.properties`:

```properties
storePassword=كلمة_مرور_المخزن
keyPassword=كلمة_مرور_المفتاح
keyAlias=hamdan
storeFile=../upload-keystore.jks
```
