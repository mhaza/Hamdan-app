import 'package:flutter/material.dart';

import '../theme.dart';

class MenuScreen extends StatelessWidget {
  const MenuScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Drawer(
      width: MediaQuery.of(context).size.width * 0.82,
      child: SafeArea(
        child: Column(
          children: [
            _buildHeader(context),
            Expanded(
              child: ListView(
                padding: EdgeInsets.zero,
                children: [
                  _buildStatusCard(),
                  const Padding(
                    padding: EdgeInsets.symmetric(horizontal: 20, vertical: 6),
                    child: Divider(),
                  ),
                  _buildPremiumButton(),
                  const SizedBox(height: 8),
                  _buildMenuItem(
                    icon: Icons.language,
                    title: 'إعدادات اللغة',
                    trailing: _LanguageDropdown(),
                  ),
                  _buildMenuItem(
                    icon: Icons.import_export,
                    title: 'نقل كل المشاريع (استيراد/تصدير)',
                  ),
                  _buildMenuItem(
                    icon: Icons.text_fields,
                    title: 'أعدادات التقارير',
                    subtitle: 'أضافة شعار واسم شركة للتقارير',
                  ),
                  _buildMenuItem(
                    icon: Icons.rate_review,
                    title: 'تقييم التطبيق على المتجر',
                  ),
                  _buildMenuItem(
                    icon: Icons.cast_for_education,
                    title: 'شرح للتطبيق',
                  ),
                  _buildMenuItem(
                    icon: Icons.ondemand_video,
                    title: 'فيديوهات شرح التطبيق',
                  ),
                  _buildMenuItem(
                    icon: Icons.support_agent,
                    title: 'تواصل مع الدعم الفني',
                  ),
                  const SizedBox(height: 24),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildHeader(BuildContext context) {
    final w = MediaQuery.of(context).size.width;
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.fromLTRB(20, 24, 20, 22),
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [HamdanColors.goldLight, HamdanColors.gold],
        ),
      ),
      child: Column(
        children: [
          CircleAvatar(
            radius: (w * 0.085).clamp(34.0, 46.0),
            backgroundColor: Colors.white,
            child: CircleAvatar(
              radius: (w * 0.08).clamp(31.0, 43.0),
              backgroundColor: HamdanColors.goldButton,
              child: Text(
                'هـ.ح',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: (w * 0.045).clamp(18.0, 24.0),
                  fontWeight: FontWeight.bold,
                  letterSpacing: 1,
                ),
              ),
            ),
          ),
          const SizedBox(height: 12),
          Text(
            'تطبيق همدان',
            style: TextStyle(
              fontSize: (w * 0.05).clamp(18.0, 22.0),
              fontWeight: FontWeight.w800,
              color: Colors.white,
            ),
          ),
          const SizedBox(height: 4),
          const Text(
            'user@hamdan.app',
            style: TextStyle(fontSize: 14, color: Colors.white70),
          ),
        ],
      ),
    );
  }

  Widget _buildStatusCard() {
    return Container(
      margin: const EdgeInsets.fromLTRB(18, 18, 18, 8),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFFF5F5F5),
        borderRadius: BorderRadius.circular(18),
      ),
      child: const Row(
        children: [
          Icon(Icons.info_outline, color: HamdanColors.textGrey, size: 34),
          SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('حالة الحساب',
                    style: TextStyle(
                        fontSize: 15, color: HamdanColors.textGrey)),
                SizedBox(height: 4),
                Text('انتهت الفترة التجريبية',
                    style: TextStyle(
                        fontSize: 17,
                        fontWeight: FontWeight.w800,
                        color: Colors.black87)),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPremiumButton() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 18, vertical: 6),
      child: Material(
        color: HamdanColors.goldButton,
        borderRadius: BorderRadius.circular(18),
        child: InkWell(
          onTap: () {},
          borderRadius: BorderRadius.circular(18),
          child: const Padding(
            padding: EdgeInsets.symmetric(vertical: 16),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(Icons.workspace_premium, color: Colors.white, size: 26),
                SizedBox(width: 10),
                Flexible(
                  child: Text(
                    'تفعيل المميزات الاحترافية',
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                        color: Colors.white,
                        fontSize: 18,
                        fontWeight: FontWeight.w800),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildMenuItem({
    required IconData icon,
    required String title,
    String? subtitle,
    Widget? trailing,
  }) {
    return ListTile(
      leading: Icon(icon, color: HamdanColors.gold, size: 28),
      title: Text(title,
          style: const TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.w600,
              color: Colors.black87)),
      subtitle: subtitle != null
          ? Text(subtitle,
              style: const TextStyle(fontSize: 13, color: HamdanColors.textGrey))
          : null,
      trailing: trailing,
      onTap: () {},
    );
  }
}

class _LanguageDropdown extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10),
      decoration: BoxDecoration(
        color: HamdanColors.goldButton,
        borderRadius: BorderRadius.circular(20),
      ),
      child: DropdownButtonHideUnderline(
        child: DropdownButton<String>(
          value: 'العربية',
          icon: const Icon(Icons.keyboard_arrow_down, color: Colors.white),
          style: const TextStyle(color: Colors.white, fontSize: 14),
          dropdownColor: HamdanColors.goldButton,
          items: const [
            DropdownMenuItem(value: 'العربية', child: Text('العربية')),
            DropdownMenuItem(value: 'English', child: Text('English')),
          ],
          onChanged: (_) {},
        ),
      ),
    );
  }
}
