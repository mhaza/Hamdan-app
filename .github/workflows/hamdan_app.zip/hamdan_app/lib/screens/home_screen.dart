import 'package:flutter/material.dart';

import '../theme.dart';
import '../widgets/background_pattern.dart';
import 'menu_screen.dart';
import 'quad_land_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: HamdanColors.background,
      appBar: AppBar(
        title: const Text('المساح'),
        leading: Builder(
          builder: (ctx) => IconButton(
            icon: const Icon(Icons.menu),
            onPressed: () => Scaffold.of(ctx).openDrawer(),
            tooltip: 'القائمة',
          ),
        ),
      ),
      drawer: const MenuScreen(),
      body: BackgroundPattern(
        child: SafeArea(
          child: LayoutBuilder(
            builder: (context, constraints) {
              final w = constraints.maxWidth;
              final h = constraints.maxHeight;
              // حساب مرن: نسبة البطاقة تعتمد على أبعاد الشاشة الفعلية
              final columns = w >= 840 ? 3 : 2; // تابلت/شاشات كبيرة
              final spacing = w * 0.045;
              final cardWidth = (w - spacing * (columns + 1)) / columns;
              final cardHeight = (cardWidth * 1.18).clamp(150.0, 260.0);

              return SingleChildScrollView(
                padding: EdgeInsets.symmetric(
                  horizontal: spacing,
                  vertical: h * 0.02,
                ),
                child: ConstrainedBox(
                  constraints: BoxConstraints(minHeight: h * 0.9),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      SizedBox(height: h * 0.035),
                      Text(
                        'أهلاً بك في تطبيق همدان',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          fontSize: (w * 0.065).clamp(20.0, 30.0),
                          fontWeight: FontWeight.w700,
                          color: Colors.white,
                          height: 1.4,
                        ),
                      ),
                      SizedBox(height: h * 0.05),
                      Wrap(
                        spacing: spacing,
                        runSpacing: spacing,
                        alignment: WrapAlignment.center,
                        children: [
                          _FeatureCard(
                            width: cardWidth,
                            height: cardHeight,
                            icon: Icons.crop_free,
                            title: 'أرض\nرباعية',
                            premium: false,
                            onTap: () => Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (_) => const QuadLandScreen(),
                              ),
                            ),
                          ),
                          _FeatureCard(
                            width: cardWidth,
                            height: cardHeight,
                            icon: Icons.area_chart,
                            title: 'أرض\nغير منتظمة',
                            premium: true,
                          ),
                          _FeatureCard(
                            width: cardWidth,
                            height: cardHeight,
                            icon: Icons.home_work,
                            title: 'حساب كميات\nمواد البناء',
                            premium: true,
                          ),
                          _FeatureCard(
                            width: cardWidth,
                            height: cardHeight,
                            icon: Icons.receipt_long,
                            title: 'حساب\nكميات وتسعير',
                            premium: true,
                          ),
                          _FeatureCard(
                            width: cardWidth,
                            height: cardHeight,
                            icon: Icons.sync_alt,
                            title: 'تحويل\nالوحدات',
                            premium: false,
                          ),
                          _FeatureCard(
                            width: cardWidth,
                            height: cardHeight,
                            icon: Icons.payments,
                            title: 'حساب\nتكلفة تقديرية',
                            premium: true,
                          ),
                        ],
                      ),
                      SizedBox(height: h * 0.04),
                    ],
                  ),
                ),
              );
            },
          ),
        ),
      ),
    );
  }
}

class _FeatureCard extends StatelessWidget {
  final double width;
  final double height;
  final IconData icon;
  final String title;
  final bool premium;
  final VoidCallback? onTap;

  const _FeatureCard({
    required this.width,
    required this.height,
    required this.icon,
    required this.title,
    this.premium = false,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.white,
      borderRadius: BorderRadius.circular(24),
      elevation: 5,
      shadowColor: HamdanColors.cardShadow,
      child: InkWell(
        onTap: onTap ?? () {},
        borderRadius: BorderRadius.circular(24),
        child: SizedBox(
          width: width,
          height: height,
          child: Stack(
            children: [
              if (premium)
                Positioned(
                  top: 10,
                  left: 10,
                  child: Container(
                    padding: const EdgeInsets.all(5),
                    decoration: const BoxDecoration(
                      color: HamdanColors.gold,
                      borderRadius: BorderRadius.all(Radius.circular(9)),
                    ),
                    child: const Icon(Icons.workspace_premium,
                        size: 18, color: Colors.white),
                  ),
                ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 14),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    CircleAvatar(
                      radius: width * 0.24,
                      backgroundColor: HamdanColors.goldPale,
                      child: Icon(icon,
                          size: (width * 0.30).clamp(30.0, 52.0),
                          color: HamdanColors.goldButton),
                    ),
                    const SizedBox(height: 14),
                    FittedBox(
                      fit: BoxFit.scaleDown,
                      child: Text(
                        title,
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          fontSize: (width * 0.11).clamp(15.0, 22.0),
                          fontWeight: FontWeight.w800,
                          color: HamdanColors.textDark,
                          height: 1.35,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
